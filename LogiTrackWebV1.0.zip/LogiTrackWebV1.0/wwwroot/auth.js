﻿// ============================================================
// LogiTrack - Shared auth & API helper
// يُستخدم في الصفحات التلاتة (index.html / driver.html / admin.html)
// ============================================================

const API_ORIGIN = window.location.origin;

function getToken() {
    return localStorage.getItem('authToken');
}

function getRole() {
    return localStorage.getItem('role');
}

function getUsername() {
    return localStorage.getItem('username');
}

function getDriverId() {
    return localStorage.getItem('driverId');
}

function isAuthenticated() {
    return !!getToken();
}

function logout(redirect = 'index.html') {
    localStorage.clear();
    window.location.href = redirect;
}

// يتأكد إن اليوزر لوجن وإن دوره مطابق للمطلوب، ولو لأ بيرجعه لصفحة اللوجين
function requireRole(role, loginPage = 'index.html') {
    if (!isAuthenticated() || getRole() !== role) {
        window.location.href = loginPage;
        return false;
    }
    return true;
}

// Wrapper حوالين fetch بيحط الـ Authorization header تلقائياً وبيرجع json جاهز
async function apiFetch(path, options = {}) {
    const headers = Object.assign(
        { 'Content-Type': 'application/json' },
        options.headers || {}
    );
    const token = getToken();
    if (token) headers['Authorization'] = `Bearer ${token}`;

    const res = await fetch(`${API_ORIGIN}/api${path}`, { ...options, headers });

    if (res.status === 401) {
        // التوكن منتهي أو مش صالح
        logout();
        throw new Error('Session expired');
    }

    let data = null;
    try {
        data = await res.json();
    } catch (e) {
        data = null;
    }

    if (!res.ok) {
        const msg = (data && (data.message || data.Message)) || `Request failed (${res.status})`;
        throw new Error(msg);
    }

    return data;
}

function unwrapList(data) {
    return Array.isArray(data) ? data : (data && data.$values) || [];
}

function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function getStatusBadgeClass(status) {
    switch (status) {
        case 'Pending': return 'badge-pending';
        case 'In Transit': return 'badge-in-transit';
        case 'Delivered': return 'badge-delivered';
        case 'Cancelled': return 'badge-pending';
        default: return 'badge-pending';
    }
}

function formatDateTime(value) {
    if (!value) return '-';
    const d = new Date(value);
    if (isNaN(d.getTime())) return value;
    return d.toLocaleString();
}