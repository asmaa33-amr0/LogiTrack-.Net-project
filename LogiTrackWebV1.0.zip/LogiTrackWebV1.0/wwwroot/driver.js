﻿// ============================================================
// LogiTrack - Driver Portal (driver.html)
// يعتمد على auth.js (لازم يتحمل قبله في الصفحة)
// ============================================================

let allDriverShipments = [];

document.addEventListener('DOMContentLoaded', () => {
    if (!requireRole('Driver', 'index.html')) return;
    checkDriverAuth();
    setupDriverEvents();
});

function checkDriverAuth() {
    const nameEl = document.getElementById('driver-name');
    if (nameEl) nameEl.textContent = getUsername() || 'Driver';

    const driverId = getDriverId();
    if (!driverId) {
        const tbody = document.getElementById('driver-shipments-body');
        if (tbody) {
            tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color: var(--danger);">
                حسابك لسه مش مربوط بسجل سواق. كلمي الأدمن عشان يربط حسابك من صفحة "السواقين".
            </td></tr>`;
        }
        return;
    }

    loadDriverData();
    loadStationsForModal();
}

function setupDriverEvents() {
    document.getElementById('btn-logout')?.addEventListener('click', () => logout('index.html'));
    document.getElementById('btn-refresh')?.addEventListener('click', loadDriverData);
}

async function loadDriverData() {
    const driverId = getDriverId();
    if (!driverId) return;

    try {
        const data = await apiFetch(`/DriverUi/driver/${driverId}`);
        const nameEl = document.getElementById('driver-name');
        if (nameEl && data.driverName) nameEl.textContent = data.driverName;

        allDriverShipments = data.shipments || [];
        renderDriverTable(allDriverShipments);
    } catch (err) {
        console.error(err);
    }
}

function filterDriverShipments() {
    const query = document.getElementById('driver-search-input').value.toLowerCase();
    const filtered = allDriverShipments.filter(item =>
        (item.trackingNumber || '').toLowerCase().includes(query) ||
        (item.destinationName || '').toLowerCase().includes(query) ||
        (item.warehouseName || '').toLowerCase().includes(query)
    );
    renderDriverTable(filtered);
}

function renderDriverTable(shipments) {
    const tbody = document.getElementById('driver-shipments-body');
    const activeEl = document.getElementById('stat-active-count');
    const completedEl = document.getElementById('stat-completed-count');

    if (!tbody) return;
    tbody.innerHTML = '';

    let active = 0;
    let completed = 0;

    if (shipments.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color: var(--text-muted);">No assigned deliveries found.</td></tr>`;
        if (activeEl) activeEl.textContent = '0';
        if (completedEl) completedEl.textContent = '0';
        return;
    }

    shipments.forEach(item => {
        const status = item.status || 'Pending';
        if (status === 'Delivered') completed++;
        else active++;

        const row = document.createElement('tr');
        row.innerHTML = `
            <td><strong>${escapeHtml(item.trackingNumber)}</strong></td>
            <td>${escapeHtml(item.warehouseName || 'Warehouse')}</td>
            <td>${escapeHtml(item.destinationName || 'N/A')}</td>
            <td>${item.weight ? item.weight + ' kg' : 'N/A'}</td>
            <td><span class="badge ${getStatusBadgeClass(status)}">${escapeHtml(status)}</span></td>
            <td>
                <div style="display:flex; gap:6px;">
                    ${renderStatusButton(item)}
                    <button class="btn-action btn-edit" onclick="openRouteModal(${item.id})">+ Route</button>
                </div>
            </td>
        `;
        tbody.appendChild(row);
    });

    if (activeEl) activeEl.textContent = active;
    if (completedEl) completedEl.textContent = completed;
}

function renderStatusButton(shipment) {
    if (shipment.status === 'Pending') {
        return `<button class="btn-action btn-add" onclick="updateStatus(${shipment.id}, 'In Transit')">Start</button>`;
    }
    if (shipment.status === 'In Transit') {
        return `<button class="btn-action btn-add" onclick="updateStatus(${shipment.id}, 'Delivered')">Deliver</button>`;
    }
    return `<span style="color:var(--text-muted); font-size:0.8rem;">Done</span>`;
}

async function updateStatus(shipmentId, newStatus) {
    try {
        await apiFetch(`/DriverUi/shipment/${shipmentId}/status`, {
            method: 'PUT',
            body: JSON.stringify({ status: newStatus })
        });
        loadDriverData();
    } catch (err) {
        alert(err.message);
    }
}

async function loadStationsForModal() {
    try {
        const list = unwrapList(await apiFetch('/Stations'));
        const select = document.getElementById('route-station-select');
        if (select) {
            select.innerHTML = '<option value="">Select Checkpoint Station</option>';
            list.forEach(s => {
                // القيمة هنا اسم المحطة نفسه لأن الـ API بتاخد StationName مش Id
                select.innerHTML += `<option value="${escapeHtml(s.name)}">${escapeHtml(s.name)}</option>`;
            });
        }
    } catch (e) {
        console.error(e);
    }
}

function openRouteModal(shipmentId) {
    document.getElementById('modal-shipment-id').value = shipmentId;
    document.getElementById('route-notes').value = '';
    document.getElementById('routeModal').style.display = 'flex';
}

function closeModal(id) {
    document.getElementById(id).style.display = 'none';
}

async function submitRoutePoint() {
    const shipmentId = document.getElementById('modal-shipment-id').value;
    const stationName = document.getElementById('route-station-select').value;
    const info = document.getElementById('route-notes').value;

    if (!stationName) { alert('اختار محطة'); return; }

    try {
        await apiFetch(`/DriverUi/shipment/${shipmentId}/checkpoint`, {
            method: 'POST',
            body: JSON.stringify({ stationName, info })
        });

        closeModal('routeModal');
        loadDriverData();
    } catch (e) {
        alert(e.message);
    }
}