﻿using LogiTrackWebV1._0;
using LogiTrackWebV1._0.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.Text.Json.Serialization;

var builder = WebApplication.CreateBuilder(args);

// 1️⃣ CORS Configuration
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

// 2️⃣ Authentication (JWT Configuration)
var jwtSettings = builder.Configuration.GetSection("Jwt");
var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings["Key"] ?? "LOGITRACK_SECURE_JWT_SECRET_KEY_32_BYTES_MINIMUM!"));

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.RequireHttpsMetadata = false;
    options.SaveToken = true;
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = jwtSettings["Issuer"] ?? "LogiTrackAPI",
        ValidAudience = jwtSettings["Audience"] ?? "LogiTrackClient",
        IssuerSigningKey = key
    };
});

builder.Services.AddAuthorization();

// 3️⃣ Controllers & JSON Options
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
    });

// 4️⃣ Database Context
builder.Services.AddDbContext<LT_DBContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("DefaultConnection")
    )
    .UseLazyLoadingProxies()
);

// 5️⃣ Identity Options
builder.Services.AddIdentity<IdentityUser, IdentityRole>(options =>
{
    options.Password.RequireDigit = false;
    options.Password.RequireLowercase = false;
    options.Password.RequireUppercase = false;
    options.Password.RequireNonAlphanumeric = false;
    options.Password.RequiredLength = 3;
})
.AddEntityFrameworkStores<LT_DBContext>()
.AddDefaultTokenProviders();

// 6️⃣ Pricing Service Registration
builder.Services.Configure<PricingOptions>(builder.Configuration.GetSection(PricingOptions.SectionName));
builder.Services.AddScoped<IPricingService, PricingService>();

// 7️⃣ Swagger Documentation
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// 1️⃣ Swagger Documentation
app.UseSwagger();
app.UseSwaggerUI();

// 2️⃣ Static Files & Routing
app.UseDefaultFiles();
app.UseStaticFiles();

app.UseRouting(); // If explicitly using Routing, place CORS right after it

// 3️⃣ CORS Middleware (MUST be before Authentication & Authorization)
app.UseCors("AllowAll");

// 4️⃣ Security & Identity
app.UseAuthentication();
app.UseAuthorization();

// 5️⃣ Endpoint Mapping
app.MapControllers();

app.Run();