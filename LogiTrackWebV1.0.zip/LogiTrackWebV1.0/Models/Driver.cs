﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace LogiTrackWebV1._0.Models
{
    public class Driver
    {
        public int Id { get; set; }
        public string FullName { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;

        // One-to-One
        
        public virtual DriverLicense License { get; set; } = null!;
        // One-to-Many
        [JsonIgnore]
        public virtual ICollection<Shipment> Shipments { get; set; } = new List<Shipment>();
    }
}
