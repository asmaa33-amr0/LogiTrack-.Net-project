﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace LogiTrackWebV1._0.Models
{
    public class DriverLicense
    {
        public int DriverId { get; set; } // PK and FK
        public string LicenseNumber { get; set; } = string.Empty;
        public DateTime ExpiryDate { get; set; }

        public virtual Driver Driver { get; set; } = null!;

    }
}