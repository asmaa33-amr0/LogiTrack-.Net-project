// Controllers/DriversController.cs
using LogiTrackWebV1._0.DTOs;
using LogiTrackWebV1._0.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LogiTrackWebV1._0.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DriversController : ControllerBase
    {
        private readonly LT_DBContext _context;

        public DriversController(LT_DBContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var drivers = await _context.Drivers
                .Select(d => new DriverDTO
                {
                    Id = d.Id,
                    FullName = d.FullName,
                    Phone = d.Phone,
                    LicenseNumber = d.License != null ? d.License.LicenseNumber : "N/A",
                    ExpiryDate = d.License != null ? d.License.ExpiryDate : DateTime.MinValue
                })
                .ToListAsync();

            return Ok(drivers);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var driver = await _context.Drivers
                .Where(d => d.Id == id)
                .Select(d => new DriverDTO
                {
                    Id = d.Id,
                    FullName = d.FullName,
                    Phone = d.Phone,
                    LicenseNumber = d.License != null ? d.License.LicenseNumber : "N/A",
                    ExpiryDate = d.License != null ? d.License.ExpiryDate : DateTime.MinValue
                })
                .FirstOrDefaultAsync();

            if (driver == null)
                return NotFound(new { message = $"Driver with id {id} not found." });

            return Ok(driver);
        }

        [HttpGet("{id}/shipments")]
        public async Task<IActionResult> GetDriverShipments(int id)
        {
            if (!await _context.Drivers.AnyAsync(d => d.Id == id))
                return NotFound(new { message = $"Driver with id {id} not found." });

            var shipments = await _context.Shipments
                .Where(s => s.DriverId == id)
                .Select(s => new
                {
                    s.Id,
                    s.TrackingNumber,
                    s.Weight,
                    s.Status,
                    WarehouseName = s.Warehouse != null ? s.Warehouse.Name : "N/A"
                })
                .ToListAsync();

            return Ok(shipments);
        }

        [HttpGet("search")]
        public async Task<IActionResult> Search(string? name, string? phone, int? id)
        {
            var query = _context.Drivers.AsQueryable();

            if (id.HasValue) query = query.Where(d => d.Id == id.Value);
            if (!string.IsNullOrEmpty(name)) query = query.Where(d => d.FullName.Contains(name));
            if (!string.IsNullOrEmpty(phone)) query = query.Where(d => d.Phone.Contains(phone));

            var drivers = await query
                .Select(d => new DriverDTO
                {
                    Id = d.Id,
                    FullName = d.FullName,
                    Phone = d.Phone,
                    LicenseNumber = d.License != null ? d.License.LicenseNumber : "N/A",
                    ExpiryDate = d.License != null ? d.License.ExpiryDate : DateTime.MinValue
                })
                .ToListAsync();

            return Ok(drivers);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] DriverDTO dto)
        {
            var driver = new Driver
            {
                FullName = dto.FullName,
                Phone = dto.Phone,
                License = new DriverLicense
                {
                    LicenseNumber = dto.LicenseNumber,
                    ExpiryDate = dto.ExpiryDate
                }
            };

            _context.Drivers.Add(driver);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetById), new { id = driver.Id }, dto);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, [FromBody] DriverDTO dto)
        {
            var existingDriver = await _context.Drivers
                .Include(d => d.License)
                .FirstOrDefaultAsync(d => d.Id == id);

            if (existingDriver == null)
                return NotFound(new { message = $"Driver with id {id} not found." });

            existingDriver.FullName = dto.FullName;
            existingDriver.Phone = dto.Phone;

            existingDriver.License ??= new DriverLicense();
            existingDriver.License.LicenseNumber = dto.LicenseNumber;
            existingDriver.License.ExpiryDate = dto.ExpiryDate;

            await _context.SaveChangesAsync();

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var driver = await _context.Drivers.FindAsync(id);
            if (driver == null)
                return NotFound(new { message = $"Driver with id {id} not found." });

            bool hasShipments = await _context.Shipments.AnyAsync(s => s.DriverId == id);
            if (hasShipments)
                return Conflict(new { message = "Driver still has shipments assigned and cannot be deleted." });

            _context.Drivers.Remove(driver);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}