// Controllers/DriverUiController.cs
using LogiTrackWebV1._0.DTOs;
using LogiTrackWebV1._0.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LogiTrackWebV1._0.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Driver,Admin")] // FIX: ��� [Authorize] ��� �ӡ �� ���� ����� ��� ���� ���� ����� �� ����
    public class DriverUiController : ControllerBase
    {
        private readonly LT_DBContext _context;
        private readonly ILogger<DriverUiController> _logger;

        public DriverUiController(LT_DBContext context, ILogger<DriverUiController> logger)
        {
            _context = context;
            _logger = logger;
        }

        [HttpGet("driver/{id}")]
        public async Task<IActionResult> GetByDriverId(int id)
        {
            try
            {
                var driver = await _context.Drivers.FirstOrDefaultAsync(d => d.Id == id);

                var shipments = await _context.Shipments
                    .Where(sh => sh.DriverId == id)
                    .Select(sh => new ShipmentListDto
                    {
                        Id = sh.Id,
                        TrackingNumber = sh.TrackingNumber,
                        Weight = sh.Weight,
                        Status = sh.Status,
                        WarehouseName = sh.Warehouse != null ? sh.Warehouse.Name : "N/A",
                        DestinationName = sh.EndStation != null ? sh.EndStation.StationName : "N/A",
                        Checkpoints = _context.RouteCheckpoints
                            .Where(c => c.ShipmentId == sh.Id)
                            .OrderBy(c => c.Timestamp)
                            .Select(c => new CheckpointDto
                            {
                                Id = c.Id,
                                StationName = c.StationName,
                                Info = c.Info,
                                Timestamp = c.Timestamp
                            })
                            .ToList()
                    })
                    .ToListAsync();

                return Ok(new
                {
                    driverName = driver != null ? driver.FullName : "Driver",
                    shipments
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to load shipments for driver {DriverId}", id);
                return StatusCode(500, new { message = "An error occurred while loading driver shipments." });
            }
        }

        [HttpGet("shipment/{id}")]
        public async Task<IActionResult> GetShipmentDetails(int id)
        {
            try
            {
                var shipment = await _context.Shipments
                    .Where(sh => sh.Id == id)
                    .Select(sh => new ShipmentDetailsDto
                    {
                        Id = sh.Id,
                        TrackingNumber = sh.TrackingNumber,
                        Weight = sh.Weight,
                        Status = sh.Status,
                        WarehouseName = sh.Warehouse != null ? sh.Warehouse.Name : "N/A",
                        DriverName = sh.Driver != null ? sh.Driver.FullName : "N/A",
                        DestinationName = sh.EndStation != null ? sh.EndStation.StationName : "N/A",
                        Address = sh.Address == null
                            ? new AddressDto()
                            : new AddressDto
                            {
                                Building = sh.Address.Building,
                                Street = sh.Address.Street,
                                City = sh.Address.City
                            },
                        Checkpoints = _context.RouteCheckpoints
                            .Where(c => c.ShipmentId == sh.Id)
                            .OrderBy(c => c.Timestamp)
                            .Select(c => new CheckpointDto
                            {
                                Id = c.Id,
                                StationName = c.StationName,
                                Info = c.Info,
                                Timestamp = c.Timestamp
                            })
                            .ToList()
                    })
                    .FirstOrDefaultAsync();

                if (shipment == null)
                    return NotFound(new { message = "Shipment not found" });

                return Ok(shipment);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to load shipment {ShipmentId}", id);
                return StatusCode(500, new { message = "An error occurred while loading the shipment." });
            }
        }

        [HttpPut("shipment/{id}/status")]
        [Authorize(Roles = "Driver,Admin")]
        public async Task<IActionResult> UpdateStatus(int id, [FromBody] UpdateStatusDto dto)
        {
            if (dto == null || string.IsNullOrWhiteSpace(dto.Status))
                return BadRequest(new { message = "Status is required" });

            try
            {
                var shipment = await _context.Shipments.FirstOrDefaultAsync(sh => sh.Id == id);
                if (shipment == null)
                    return NotFound(new { message = "Shipment not found" });

                shipment.Status = dto.Status;
                await _context.SaveChangesAsync();

                return Ok(new { message = "Status updated successfully" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to update status for shipment {ShipmentId}", id);
                return StatusCode(500, new { message = "An error occurred while updating the status." });
            }
        }

        [HttpPost("shipment/{shipmentId}/checkpoint")]
        [Authorize(Roles = "Driver,Admin")]
        public async Task<IActionResult> AddCheckpoint(int shipmentId, [FromBody] CreateCheckpointDto dto)
        {
            if (dto == null || string.IsNullOrWhiteSpace(dto.StationName))
                return BadRequest(new { message = "Station name is required" });

            try
            {
                var shipmentExists = await _context.Shipments.AnyAsync(s => s.Id == shipmentId);
                if (!shipmentExists)
                    return NotFound(new { message = "Shipment not found." });

                var checkpoint = new RouteCheckpoint
                {
                    ShipmentId = shipmentId,
                    StationName = dto.StationName,
                    Info = dto.Info ?? "Checkpoint reached",
                    Timestamp = dto.Timestamp ?? DateTime.Now
                };

                _context.RouteCheckpoints.Add(checkpoint);
                await _context.SaveChangesAsync();

                return Ok(new
                {
                    message = "Checkpoint added successfully",
                    checkpoint = new CheckpointDto
                    {
                        Id = checkpoint.Id,
                        StationName = checkpoint.StationName,
                        Info = checkpoint.Info,
                        Timestamp = checkpoint.Timestamp
                    }
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to add checkpoint for shipment {ShipmentId}", shipmentId);
                return StatusCode(500, new { message = "An error occurred while adding the checkpoint." });
            }
        }

        [HttpGet("shipment/{shipmentId}/checkpoints")]
        public async Task<IActionResult> GetCheckpoints(int shipmentId)
        {
            try
            {
                var checkpoints = await _context.RouteCheckpoints
                    .Where(c => c.ShipmentId == shipmentId)
                    .OrderBy(c => c.Timestamp)
                    .Select(c => new CheckpointDto
                    {
                        Id = c.Id,
                        StationName = c.StationName,
                        Info = c.Info,
                        Timestamp = c.Timestamp
                    })
                    .ToListAsync();

                return Ok(checkpoints);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to load checkpoints for shipment {ShipmentId}", shipmentId);
                return StatusCode(500, new { message = "An error occurred while loading checkpoints." });
            }
        }
    }
}