﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using LogiTrackWebV1._0.Models;

namespace LogiTrackWebV1._0.Configrations
{
    internal class DriverConfig : IEntityTypeConfiguration<Driver>
    {
        public void Configure(EntityTypeBuilder<Driver> builder)
        {
            builder.HasKey(d => d.Id);

            builder.Property(d => d.FullName)
            .IsRequired();
 


            builder.Property(d => d.Phone)
                .IsRequired();



            builder.HasOne(d => d.License)
                .WithOne(l => l.Driver)
                .HasForeignKey<DriverLicense>(l => l.DriverId)
                .OnDelete(DeleteBehavior .Cascade);
        }
    }
}
