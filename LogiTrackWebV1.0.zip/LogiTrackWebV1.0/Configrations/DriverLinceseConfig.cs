﻿using LogiTrackWebV1._0.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogiTrackWebV1._0.Configrations
{
    internal class DriverLinceseConfig :IEntityTypeConfiguration<DriverLicense>
    {
        public  void Configure(EntityTypeBuilder<DriverLicense>builder) 
        {
            builder.HasKey(l => l.LicenseNumber);

            builder.Property(l => l.LicenseNumber)
            .IsRequired()
            .HasMaxLength(50);


            builder.Property(l => l.ExpiryDate)
                .IsRequired();

            

        }
    }
}
