﻿using System;

namespace LogiTrackWebV1._0.DTOs
{
    public class DriverDTO
    {
        public int Id { get; set; }
        public string FullName { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
        public string LicenseNumber { get; set; } = string.Empty;
        public DateTime ExpiryDate { get; set; }
    }
}